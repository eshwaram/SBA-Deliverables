export class User {
    public userID: string;
    public fName: string;
    public lName: string;
    public empID: string;

    constructor() {
    }

}
